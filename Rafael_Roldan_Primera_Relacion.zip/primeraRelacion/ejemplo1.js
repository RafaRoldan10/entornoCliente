console.log("texto en documento");
document.write("texto en archivo");