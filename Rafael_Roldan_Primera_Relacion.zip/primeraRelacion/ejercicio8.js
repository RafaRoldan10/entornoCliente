var ventana;
function abreVentana(){
    ventana = window.open();
}